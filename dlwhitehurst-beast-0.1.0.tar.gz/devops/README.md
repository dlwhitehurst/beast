# Devops

This folder contains a shell script to create a beast control container
for a Linux environment to run Ansible that builds and provisions a
beast cluster.

